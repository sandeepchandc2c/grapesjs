/* ../../fontforge/is_LIGATURE.c */
int is_LIGATURE_or_VULGAR_FRACTION(unsigned int codepoint);
