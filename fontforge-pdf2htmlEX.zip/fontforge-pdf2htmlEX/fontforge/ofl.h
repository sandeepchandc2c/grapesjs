#include "splinefont.h"

extern struct str_lang_data {
    enum ttfnames strid;
    int lang;
    char **data;
} ofl_str_lang_data[];
