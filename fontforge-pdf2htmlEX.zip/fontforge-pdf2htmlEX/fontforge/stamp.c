/* This file was generated using stamper.c to create the next version release.          */
/* If you need to update this to the next release version, see fontforge/GNUmakefile.in */

#include <fontforge-config.h>
#include <time.h>

const time_t source_modtime    = FONTFORGE_MODTIME_RAW;	/* Seconds since 1970 (standard unix time) */
const char *source_modtime_str = FONTFORGE_MODTIME_STR;
const char *source_version_str = FONTFORGE_VERSIONDATE;	/* Year, month, day */
