#!/bin/sh
script $HOME/FontForge-Debug-Output.txt lldb --debug --source fontforge-debug-lldb-script.txt --
